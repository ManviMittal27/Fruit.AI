// src/App.js
import React, { useState } from 'react';
import FruitList from './components/FruitList';
import FruitDetail from './components/FruitDetail';
import './App.css';

function App() {
  const [selectedFruit, setSelectedFruit] = useState(null);

  const handleSelectFruit = (fruit) => {
    setSelectedFruit(fruit);
  };

  return (
    <div className="app">
      <div className="fruit-list-section">
        <h2>Fruit List</h2>
        <FruitList onSelectFruit={handleSelectFruit} />
      </div>
      <div className="fruit-detail-section">
        <h2>Fruit Details</h2>
        <FruitDetail fruit={selectedFruit} />
      </div>
    </div>
  );
}

export default App;
