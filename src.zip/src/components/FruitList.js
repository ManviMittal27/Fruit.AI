// src/components/FruitList.js
import React from 'react';
import FruitCard from './FruitCard';

const fruits = [
  { id: 1, name: 'Apple', description: 'A popular fruit known for its crisp texture and sweet flavor. Apples come in various colors, including red, green, and yellow, and are often eaten fresh or used in baking.', image: '/images/apple.jpg' },
  { id: 2, name: 'Banana', description: 'A long, curved fruit with a soft, sweet flesh and a yellow skin. Bananas are a great source of potassium and are commonly used in smoothies, cereals, and desserts.', image: '/images/banana.webp' },
  { id: 3, name: 'Cherry', description: 'A small, round fruit that can be sweet or tart. Cherries are typically red or dark purple and are enjoyed fresh or used in pies, jams, and as a garnish.', image: '/images/cherry.jpg' },
  { id: 4, name: 'Date', description: 'A sweet, chewy fruit that comes from the date palm tree. Dates are often eaten dried and are used in various desserts and energy bars due to their natural sweetness and high fiber content.', image: '/images/date.png' },
  { id: 5, name: 'Fig', description: 'A small, sweet fruit with a unique texture. Figs have a smooth skin, soft flesh, and tiny seeds. They can be eaten fresh or dried and are often used in baking and salads.', image: '/images/fig.jpg' },
  { id: 6, name: 'Grape', description: 'A small, round fruit that comes in green, red, and black varieties. Grapes are juicy and sweet and can be eaten fresh, dried into raisins, or used to make wine and juices.', image: '/images/grape.jpg' },
  { id: 7, name: 'Kiwi', description: 'A green, fuzzy fruit with a tangy and sweet flavor. The flesh is bright green with tiny black seeds. Kiwi is rich in vitamin C and is often used in fruit salads and desserts.', image: '/images/kiwi.avif' },
  { id: 8, name: 'Lemon', description: 'A bright yellow citrus fruit known for its tart, tangy flavor. Lemons are commonly used to add flavor to dishes, make lemonade, or as a natural cleaning agent.', image: '/images/lemon.jpg' },
  { id: 9, name: 'Mango', description: 'A tropical fruit with a sweet, juicy flesh and a vibrant orange color. Mangoes are eaten fresh, used in smoothies, or made into salsas and desserts.', image: '/images/mango.jpg' },
  { id: 10, name: 'Orange', description: 'A popular citrus fruit with a tangy, sweet flavor. Oranges are typically eaten fresh or juiced and are known for their high vitamin C content.', image: '/images/orange.jpg' },
];

function FruitList({ onSelectFruit }) {
  return (
    <div className="fruit-list">
      {fruits.map((fruit) => (
        <FruitCard key={fruit.id} fruit={fruit} onClick={() => onSelectFruit(fruit)} />
      ))}
    </div>
  );
}

export default FruitList;
