// src/components/FruitDetail.js
import React from 'react';

function FruitDetail({ fruit }) {
  if (!fruit) {
    return <p>Please select a fruit to see details.</p>;
  }

  return (
    <div className="fruit-detail">
      <img src={fruit.image} alt={fruit.name} className="fruit-detail-image" />
      <h2>{fruit.name}</h2>
      <p>{fruit.description}</p>
    </div>
  );
}

export default FruitDetail;
