// src/components/FruitCard.js
import React from 'react';

function FruitCard({ fruit, onClick }) {
  return (
    <div className="fruit-card" onClick={onClick}>
      <img src={fruit.image} alt={fruit.name} className="fruit-image" />
      <h3>{fruit.name}</h3>
      <p>{fruit.description.slice(0, 100)}{fruit.description.length > 100 ? '...' : ''}</p>
    </div>
  );
}

export default FruitCard;
